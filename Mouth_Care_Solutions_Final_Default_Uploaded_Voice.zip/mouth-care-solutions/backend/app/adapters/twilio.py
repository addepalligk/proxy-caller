import base64, hashlib, hmac
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from xml.sax.saxutils import escape

def validate_twilio_signature(auth_token: str, url: str, params: dict, signature: str|None) -> bool:
    if not auth_token or not signature:
        return False
    payload = url + ''.join(k + str(params[k]) for k in sorted(params))
    digest = base64.b64encode(
        hmac.new(auth_token.encode(), payload.encode(), hashlib.sha1).digest()
    ).decode()
    return hmac.compare_digest(digest, signature)

class TwilioVoiceGateway:
    def __init__(self, account_sid: str, auth_token: str, phone_number: str):
        self.account_sid = account_sid
        self.auth_token = auth_token
        self.phone_number = phone_number

    def _action(self, webhook_base_url=''):
        base = (webhook_base_url or '').rstrip('/')
        return f'{base}/api/telephony/twilio/voice' if base else '/api/telephony/twilio/voice'

    def inbound_twiml(self, greeting='Welcome to Mouth Care Solutions. How may I help you?', webhook_base_url=''):
        return self.conversation_twiml(greeting, webhook_base_url)

    def conversation_twiml(self, speech, webhook_base_url=''):
        action = self._action(webhook_base_url)
        return (
            '<Response>'
            f'<Gather input="speech dtmf" action="{escape(action)}" method="POST" '
            'speechTimeout="auto" timeout="5">'
            f'<Say>{escape(str(speech))}</Say>'
            '</Gather>'
            '<Say>I did not hear anything. Please call the clinic again if you still need help.</Say>'
            '<Hangup/>'
            '</Response>'
        )

    def audio_twiml(self, audio_url, webhook_base_url=''):
        """Play generated audio, then collect the caller's next turn."""
        action = self._action(webhook_base_url)
        return (
            '<Response>'
            f'<Gather input="speech dtmf" action="{escape(action)}" method="POST" '
            'speechTimeout="auto" timeout="5">'
            f'<Play>{escape(str(audio_url))}</Play>'
            '</Gather>'
            '<Hangup/>'
            '</Response>'
        )

def create_outbound_call(account_sid: str, auth_token: str, from_number: str, to_number: str, webhook_url: str, status_url: str) -> dict:
    if not all((account_sid, auth_token, from_number, to_number, webhook_url, status_url)):
        raise RuntimeError('twilio_outbound_configuration_missing')
    body = urlencode({
        'To': to_number,
        'From': from_number,
        'Url': webhook_url,
        'StatusCallback': status_url,
        'StatusCallbackEvent': 'initiated ringing answered completed'
    }).encode()
    req = Request(
        f'https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Calls.json',
        data=body,
        method='POST'
    )
    token = base64.b64encode(f'{account_sid}:{auth_token}'.encode()).decode()
    req.add_header('Authorization', f'Basic {token}')
    req.add_header('Content-Type', 'application/x-www-form-urlencoded')
    with urlopen(req, timeout=15) as response:
        import json
        data = json.loads(response.read().decode())
    return {'call_sid': data.get('sid'), 'status': data.get('status', 'queued')}
