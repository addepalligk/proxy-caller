# Fish Speech local voice path

The production telephony voice path is:

> Agent response text → local Fish Speech `/v1/tts` → 8 kHz mono 16-bit WAV → Twilio `<Play>`

The application does not load the Fish model inside each request. Run the Fish Speech API server as a separate long-lived process so it loads its model once and serves repeated requests.

## Hardware boundary

The current Fish Speech S2 Pro documentation recommends at least **24 GB of GPU memory** for inference. The original development machine has 6 CPU cores, 7.8 GiB RAM, and no NVIDIA GPU/CUDA. S2 Pro installation and weight download succeeded there, but CPU model startup was OOM-killed with exit code 137. The application records generation latency and real-time factor rather than claiming real-time performance.

## Linux installation

From a machine with sufficient resources:

```bash
git clone https://github.com/fishaudio/fish-speech.git
cd fish-speech
python3.12 -m venv .venv
. .venv/bin/activate
pip install -e '.[cu129]'       # select the CUDA extra matching the machine
hf download fishaudio/s2-pro --local-dir checkpoints/s2-pro
python tools/api_server.py --listen 0.0.0.0:8080 --device cuda --half
```

For CPU-only testing, use `pip install -e '.[cpu]'` and `--device cpu`. The local API is `POST http://127.0.0.1:8080/v1/tts`. The adapter sends JSON containing `text`, `format: wav`, `streaming: false`, and optional reference audio or reference ID.

The supplied project includes `scripts/run_fish_speech.sh`, which performs install, model-download, hardware checks, and server startup after the operator supplies a Fish Speech checkout.

## Windows PowerShell

Use `scripts/run_fish_speech.ps1`. It checks Python 3.12+, Git, FFmpeg, NVIDIA availability, RAM, the Fish Speech checkout, and model weights. It defaults to CUDA and refuses a CPU S2 Pro start on a host below the documented memory threshold unless CPU testing is explicitly requested:

```powershell
 .\scripts\run_fish_speech.ps1 -Backend cuda
# Explicit CPU experiment only:
 .\scripts\run_fish_speech.ps1 -Backend cpu -AllowCpu
```

A compatible NVIDIA driver/runtime is required for the CUDA path. Native Windows is supported by this launcher; WSL is not required by the project launcher.

## Docker Compose

The `voice` Compose profile includes the official `fishaudio/fish-speech:latest` service. Model weights are mounted from `FISH_SPEECH_CHECKPOINTS_DIR` (default `./fish-checkpoints`) and reference files from `FISH_SPEECH_REFERENCES_DIR` (default `./fish-references`). The API container reaches Fish Speech at the Docker service hostname `http://fish-speech:8080`, not `127.0.0.1`:

```powershell
$env:FISH_SPEECH_ENABLED = "true"
$env:FISH_SPEECH_DEVICE = "cuda"
docker compose --profile voice up --build
```

The official container requires a compatible NVIDIA runtime for the CUDA configuration. On a CPU-only machine, use the launcher with an explicitly authorized CPU test; the current S2 Pro model may not fit in small-memory hosts.

## Application configuration

Copy `.env.example` to `.env` and set:

```dotenv
FISH_SPEECH_ENABLED=true
FISH_SPEECH_BASE_URL=http://127.0.0.1:8080
FISH_SPEECH_MODEL=s2-pro
FISH_SPEECH_OUTPUT_FORMAT=wav
FISH_SPEECH_SAMPLE_RATE=8000
FISH_SPEECH_CHANNELS=1
FISH_SPEECH_TIMEOUT_SECONDS=30
```

When running through Compose, set `FISH_SPEECH_BASE_URL=http://fish-speech:8080`. Only use authorized reference audio. Set `FISH_SPEECH_REFERENCE_AUDIO` and `FISH_SPEECH_REFERENCE_TEXT`, or configure a server-side `FISH_SPEECH_REFERENCE_ID`.

## Telephone conversion and delivery

Fish output is converted with FFmpeg to 8 kHz, mono, signed 16-bit PCM WAV. The FastAPI application stores the short-lived artifact at `/api/telephony/audio/{audio_id}`. Twilio receives a `<Play>` URL pointing at that endpoint and then posts the next speech turn to `/api/telephony/twilio/voice`.

When `FISH_SPEECH_ENABLED=true`, active voice routes do not use Twilio `<Say>`. Demo-mode `<Say>` behavior remains only as an isolated compatibility path when Fish Speech is disabled. All Twilio POST routes validate `X-Twilio-Signature` in live mode.

## Readiness and status

`/ready` reports `fish_speech.configured` separately from `fish_speech.reachable`. In live mode it returns HTTP 503 until the configured Fish Speech `/v1/health` endpoint responds successfully. `/api/status` reports `voice: fish-speech` when the provider is enabled.

## Tests and measurements

The adapter tests validate text rejection, HTTP response handling, FFmpeg conversion, WAV format, TwiML `<Play>` generation, and end-to-end route-to-audio retrieval. Generation logs include source text length, output duration, latency, and real-time factor (`latency / audio_duration`). Real S2 Pro audio requires a host on which the official model can remain resident; the CPU-only sandbox could not meet that requirement.

## Verified constrained-host model

`fishaudio/fish-speech-1.5` with the official Fish Speech `v1.5.1` server was verified on the CPU-only sandbox. It generated real speech at 44.1 kHz mono, which the project adapter converted to telephone WAV. The direct adapter run produced 4.923 seconds of 8 kHz telephone audio in 248.329 seconds (RTF 50.446). The end-to-end agent route produced TwiML with `<Play>` and no `<Say>` in 271.495 seconds. This is functional but far too slow for interactive telephony on CPU; use a GPU host for production latency.

The verified model is now the default in the launchers and `.env.example` (`fish-speech-1.5`, server checkout `v1.5.1`). Set `FISH_SPEECH_MODEL=s2-pro` and use a sufficiently provisioned GPU host only when S2 Pro quality is required.

## Uploaded reference voice

The project distribution includes `fish-references/mouth-care-receptionist-reference.wav`, extracted from the authorized uploaded WhatsApp recording. It is mono 44.1 kHz PCM, approximately 21.95 seconds, with no detected clipping. The matching transcript is configured through `FISH_SPEECH_REFERENCE_TEXT`; the adapter sends the audio as a base64 `references` item with that transcript to the Fish Speech `/v1/tts` API.

Set:

```dotenv
FISH_SPEECH_REFERENCE_AUDIO=fish-references/mouth-care-receptionist-reference.wav
FISH_SPEECH_REFERENCE_TEXT=Tomorrow is holiday because of Sunday. The Sunday is because of today is Saturday. Today is Saturday is because of yesterday is Friday. Friday is because of Thursday. But I know you are not willing to listen, but you have to listen.
```

The reference is only used when Fish Speech is enabled. It is not prerecorded response audio; every response is generated dynamically by Fish Speech. Reference voice quality should be evaluated on the target GPU host because CPU inference is extremely slow and the current sandbox cannot independently judge subjective vocal similarity beyond waveform and transcription checks.
