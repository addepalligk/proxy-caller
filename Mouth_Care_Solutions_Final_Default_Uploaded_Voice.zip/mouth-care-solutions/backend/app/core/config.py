from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    app_name: str = 'Mouth Care Solutions AI Receptionist'
    app_mode: str = 'demo'
    clinic_email: str = 'mouthcaresolutions@gmail.com'
    admin_demo_token: str = 'demo-admin-token'
    admin_initial_email: str = ''
    admin_initial_password: str = ''
    pilot_minutes: int = 3000
    database_url: str = 'postgresql://postgres:postgres@db:5432/mouthcare'
    clinic_phone: str = '+919642340630'
    mock_mode: bool = True
    llm_provider: str = 'openai-compatible'
    llm_api_key: str = ''
    frontend_api_base_url: str = 'http://localhost:8000'
    vite_api_base_url: str = ''
    google_calendar_credentials: str = ''
    notification_provider: str = 'mock'
    elevenlabs_api_key: str = ''
    elevenlabs_agent_id: str = ''
    elevenlabs_voice_id: str = ''
    openai_api_key: str = ''
    openai_api_base: str = 'https://api.openai.com/v1'
    llm_model: str = 'gpt-4o-mini'
    twilio_account_sid: str = ''
    twilio_auth_token: str = ''
    twilio_phone_number: str = '+17372212163'
    twilio_webhook_base_url: str = ''
    twilio_status_callback_url: str = ''
    outbound_call_script: str = 'Hello, this is the Mouth Care Solutions AI receptionist. How may I help you today?'
    fish_speech_enabled: bool = False
    fish_speech_base_url: str = 'http://127.0.0.1:8080'
    fish_speech_model: str = 'fish-speech-1.5'
    fish_speech_reference_audio: str = ''
    fish_speech_reference_text: str = ''
    fish_speech_reference_id: str = ''
    fish_speech_output_format: str = 'wav'
    fish_speech_sample_rate: int = 8000
    fish_speech_channels: int = 1
    fish_speech_timeout_seconds: float = 30.0
    fish_speech_max_new_tokens: int = 256
    fish_speech_audio_ttl_seconds: int = 300
    jwt_secret: str = 'change-me-in-live-mode'
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    def validate_live(self) -> list[str]:
        required = []
        if self.mock_mode:
            return required
        if not self.database_url:
            required.append('DATABASE_URL')
        if not self.llm_api_key and not self.openai_api_key:
            required.append('LLM_API_KEY or OPENAI_API_KEY')
        if not self.fish_speech_enabled:
            required.append('FISH_SPEECH_ENABLED')
        if self.fish_speech_enabled and not self.fish_speech_base_url:
            required.append('FISH_SPEECH_BASE_URL')
        if not self.twilio_auth_token:
            required.append('TWILIO_AUTH_TOKEN')
        if self.jwt_secret == 'change-me-in-live-mode':
            required.append('JWT_SECRET')
        if not self.admin_initial_email or not self.admin_initial_password:
            required.append('ADMIN_INITIAL_EMAIL and ADMIN_INITIAL_PASSWORD')
        required.append('LIVE_POSTGRES_BOOKING_REPOSITORY')
        return required
settings = Settings()
