# Mouth Care Solutions — AI Voice Receptionist Demo

A runnable, provider-neutral demo/pilot for Mouth Care Solutions. The demo uses **FastAPI + Pydantic** with an in-memory repository by default, so it runs without paid credentials. A React/Vite frontend source is included, plus a no-build browser demo served by the API for immediate verification.

> **Safety boundary:** clinic facts are limited to the supplied specification. Prices, doctor roster, insurance, durations, cancellation policy, holiday calendar, and live scheduling are intentionally not fabricated.

## Quick start

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r backend/requirements.txt
uvicorn backend.app.main:app --reload
# open http://localhost:8000/demo
```

OpenAPI: http://localhost:8000/docs. Health: `/health`; readiness: `/ready`.

With Docker:

```bash
docker compose up --build
```

The API runs in mock mode unless `APP_MODE=production` and provider credentials are configured. The demo workflow supports clinic info, service questions, safe emergency guidance, slot search, explicit confirmation, reschedule/cancel, callback, escalation, usage metrics, and a lightweight admin panel.

## Repository

- `backend/app`: API, deterministic agent policy, booking engine, adapters, models, schemas.
- `frontend`: React/Vite source for a production-style client; `backend/app/static`: zero-build demo client.
- `migrations/001_initial.sql`: PostgreSQL-compatible schema outline with constraints and audit tables.
- `knowledge/clinic/approved.json`: versioned approved facts only.
- `docs`: architecture, API, policy, security, testing, deployment, gap register, demo script, acceptance checklist.

## Configuration

Copy `.env.example` to `.env`. Mock adapters are the default. ElevenLabs, Twilio, Google Calendar, and notification adapters are interfaces/configuration points only until credentials, contracts, consent, and operational policies are supplied. Never commit secrets.

## Tests

```bash
pytest -q
```

## Admin demo

The demo admin view is intentionally local/mock-only. Production must replace it with authenticated sessions, password hashing/SSO, CSRF protection, and role checks. Roles are `receptionist`, `manager`, `admin`, and `developer`.

## Production hardening

Configure a live scheduling source, approved provider roster, durations, pricing, cancellation/no-show policy, holidays, escalation target, recording and consent wording, language policy, patient verification, notification provider, operational owner, vendor/data-processing contracts, budget/overage policy, PostgreSQL, pgvector, HTTPS, durable queues, rate limits, secret manager, monitoring, backups, retention, and a clinical/legal review.

## Packaging

The deliverable is `Mouth_Care_Solutions_AI_Receptionist_FINAL_REPAIRED_COMPLETE.zip`, containing this project without caches, virtual environments, secrets, or build artifacts.

## Local Fish Speech voice

The active live telephony voice path can use the local Fish Speech API server. See `docs/fish-speech.md` and `scripts/run_fish_speech.sh`. Set `FISH_SPEECH_ENABLED=true` only after the Fish Speech server is reachable; the adapter converts generated audio to 8 kHz mono 16-bit WAV and Twilio receives it through `<Play>`. Do not include `.env` or credentials in source archives.
