# Testing

Run pytest -q. Core booking and policy logic is testable without voice. Add contract and provider integration tests when real adapters are configured.
