from fastapi import FastAPI, Header, HTTPException, Request
import base64, hashlib, hmac
from fastapi.responses import HTMLResponse, Response
from urllib.parse import parse_qsl
import httpx
from .schemas.api import *
from .services.repository import Repo
from .services.engine import Agent, CLINIC, SERVICES
from .core.config import settings
from .adapters.twilio import validate_twilio_signature, TwilioVoiceGateway, create_outbound_call
from .adapters.fish_speech import AudioStore, FishSpeechAdapter, FishSpeechError
from .auth import hash_password, verify_password
app=FastAPI(title='Mouth Care Solutions AI Receptionist',version='1.0.0')
repo=Repo(); agent=Agent(repo)
repo.call_requests=[]
audio_store=AudioStore(settings.fish_speech_audio_ttl_seconds)
fish_speech=FishSpeechAdapter(
    settings.fish_speech_base_url,
    timeout_seconds=settings.fish_speech_timeout_seconds,
    output_format=settings.fish_speech_output_format,
    telephone_sample_rate=settings.fish_speech_sample_rate,
    telephone_channels=settings.fish_speech_channels,
    max_new_tokens=settings.fish_speech_max_new_tokens,
    reference_audio=settings.fish_speech_reference_audio,
    reference_text=settings.fish_speech_reference_text,
    reference_id=settings.fish_speech_reference_id,
)
@app.get('/', response_class=HTMLResponse)
def root(): return HTMLResponse('<meta http-equiv="refresh" content="0; url=/demo"><a href="/demo">Open Mouth Care Solutions receptionist demo</a>')
@app.get('/favicon.ico')
def favicon(): return HTMLResponse('', status_code=204)
_demo_admin_hash = hash_password('demo-password')
def _session_token(role='admin'):
 payload=f'{role}:admin'; sig=hmac.new(settings.jwt_secret.encode(),payload.encode(),hashlib.sha256).hexdigest(); return 'mcs.'+base64.urlsafe_b64encode(payload.encode()).decode()+'.'+sig
def _admin_allowed(authorization):
 if settings.mock_mode and authorization == 'Bearer demo-admin-token': return True
 if not authorization or not authorization.startswith('Bearer mcs.'): return False
 try:
  _,encoded,sig=authorization.split('.',2); payload=base64.urlsafe_b64decode(encoded).decode(); expected=hmac.new(settings.jwt_secret.encode(),payload.encode(),hashlib.sha256).hexdigest(); return hmac.compare_digest(sig,expected) and payload.endswith(':admin')
 except (ValueError, UnicodeDecodeError): return False
def err(e): raise HTTPException(400,str(e))
def _twilio_public_url(request: Request) -> str:
    """Build the public URL Twilio used for its signature calculation."""
    base = (settings.twilio_webhook_base_url or "").rstrip("/")
    if not base:
        return str(request.url)
    path = request.url.path
    query = request.url.query
    return f"{base}{path}" + (f"?{query}" if query else "")


async def _twilio_params(request: Request) -> dict:
    """Read Twilio's application/x-www-form-urlencoded POST parameters."""
    body = await request.body()
    if not body:
        return {}
    return dict(parse_qsl(body.decode("utf-8"), keep_blank_values=True))


def _validate_twilio_request(request: Request, params: dict, signature: str | None) -> None:
    if settings.mock_mode:
        return
    if not signature:
        raise HTTPException(status_code=403, detail="invalid_twilio_signature")
    public_url = _twilio_public_url(request)
    if not validate_twilio_signature(settings.twilio_auth_token, public_url, params, signature):
        raise HTTPException(status_code=403, detail="invalid_twilio_signature")


async def _voice_response(request: Request, response_text: str) -> HTMLResponse:
    """Synthesize agent text and return TwiML that plays generated audio."""
    if not settings.fish_speech_enabled:
        if settings.mock_mode:
            return HTMLResponse(
                TwilioVoiceGateway('', '', settings.twilio_phone_number).conversation_twiml(
                    response_text, settings.twilio_webhook_base_url
                ),
                media_type='application/xml',
            )
        raise HTTPException(status_code=503, detail='fish_speech_not_configured')
    try:
        artifact = await fish_speech.synthesize(response_text)
        await audio_store.put(artifact)
    except (FishSpeechError, ValueError) as exc:
        raise HTTPException(status_code=503, detail='fish_speech_unavailable') from exc
    base = (settings.twilio_webhook_base_url or str(request.base_url)).rstrip('/')
    audio_url = f'{base}/api/telephony/audio/{artifact.audio_id}'
    return HTMLResponse(
        TwilioVoiceGateway(
            settings.twilio_account_sid,
            settings.twilio_auth_token,
            settings.twilio_phone_number,
        ).audio_twiml(audio_url, settings.twilio_webhook_base_url or base),
        media_type='application/xml',
    )


@app.get('/health')
def health(): return {'status':'ok','mode':'demo' if settings.mock_mode else 'live'}
@app.get('/api/telephony/audio/{audio_id}')
async def generated_audio(audio_id: str):
 artifact = await audio_store.get(audio_id)
 if not artifact: raise HTTPException(404, 'audio_not_found')
 return Response(content=artifact.content, media_type=artifact.content_type, headers={'Cache-Control':'no-store'})
@app.get('/ready')
def ready():
 missing = settings.validate_live()
 if missing: raise HTTPException(503, {'status':'not_ready','missing_configuration':missing})
 fish_configured = bool(settings.fish_speech_enabled and settings.fish_speech_base_url)
 fish_reachable = False
 if fish_configured:
  try:
   response = httpx.get(f'{settings.fish_speech_base_url.rstrip("/")}/v1/health', timeout=2.0)
   fish_reachable = response.status_code == 200
  except httpx.HTTPError:
   fish_reachable = False
 if not settings.mock_mode and fish_configured and not fish_reachable:
  raise HTTPException(503, {'status':'not_ready','fish_speech':{'configured':True,'reachable':False}})
 return {'status':'ready','database':'in-memory-demo' if settings.mock_mode else 'postgresql','providers':{'voice':'fish-speech' if fish_configured else ('mock' if settings.mock_mode else 'not_configured'),'notifications':settings.notification_provider,'telephony':'mock' if settings.mock_mode else 'twilio'},'fish_speech':{'configured':fish_configured,'reachable':fish_reachable}}
@app.post('/api/agent/session')
def session(r:AgentRequest): return agent.respond(r.message,r.session_id or 'demo-session')
@app.post('/api/knowledge/search')
def search(r:KnowledgeRequest): return agent.respond(r.query,'knowledge-search')
@app.get('/api/slots')
def slots(): return {'slots':[repo.slot_view(s) for s in repo.available()]}
@app.post('/api/booking/hold')
def hold(r:HoldRequest):
 try:return repo.hold(r.slot_id,r.session_id,r.expiry_seconds)
 except ValueError as e: err(e)
@app.post('/api/booking/confirm')
def confirm(r:ConfirmRequest):
 try:return repo.confirm(r.hold_token,r.patient_details,r.consent,r.idempotency_key)
 except ValueError as e: err(e)
@app.post('/api/booking/reschedule')
def reschedule(r:RescheduleRequest):
 try:return repo.reschedule(r.booking_reference,r.new_slot_id,r.verification)
 except ValueError as e: err(e)
@app.post('/api/booking/cancel')
def cancel(r:CancelRequest):
 try:return repo.cancel(r.booking_reference,r.reason,r.verification)
 except ValueError as e: err(e)
@app.post('/api/callback')
def callback(r:CallbackRequest):
 item={'id':f'DEMO-CB-{len(repo.callbacks)+1:03d}',**r.model_dump(),'status':'queued'}; repo.callbacks.append(item); repo.log('callback_created',item); return item
@app.get('/api/status')
def public_status(): return {'mode':'demo' if settings.mock_mode else 'live','voice':'fish-speech' if settings.fish_speech_enabled else ('mock' if settings.mock_mode else 'not_configured'),'telephony':'mock' if settings.mock_mode else ('twilio' if settings.twilio_auth_token else 'twilio_not_configured'),'clinic_phone':settings.clinic_phone}
@app.post('/api/calls/request')
def call_request(r:CallRequest):
 if not r.consent: raise HTTPException(400,'consent_required')
 item={'request_id':f'DEMO-CALL-{len(repo.call_requests)+1:04d}','name':r.name,'patient_contact':r.patient_contact,'preferred_window':r.preferred_window,'topic':r.topic,'status':'queued','mode':'demo'}
 if not settings.mock_mode:
  if not settings.twilio_webhook_base_url: raise HTTPException(503,'live_twilio_webhook_base_url_missing')
  if not settings.twilio_account_sid or not settings.twilio_auth_token or not settings.twilio_phone_number: raise HTTPException(503,'live_twilio_configuration_missing')
  try:
   provider=create_outbound_call(settings.twilio_account_sid,settings.twilio_auth_token,settings.twilio_phone_number,r.patient_contact,settings.twilio_webhook_base_url.rstrip('/')+'/api/telephony/twilio/outbound',settings.twilio_status_callback_url or settings.twilio_webhook_base_url.rstrip('/')+'/api/telephony/twilio/status')
   item.update({'request_id':'CALL-'+provider['call_sid'],'status':provider['status'],'mode':'live','call_sid':provider['call_sid']})
  except Exception as exc: raise HTTPException(502,'live_call_provider_unavailable') from exc
 repo.call_requests.append(item); repo.log('call_request_created',{'request_id':item['request_id'],'status':item['status'],'mode':item['mode']}); return {'request_id':item['request_id'],'status':item['status'],'message':'Your call request has been received.','mode':item['mode']}
@app.post('/api/call-request')
def simple_call_request(r:SimpleCallRequest):
 if ''.join(ch for ch in r.phone_number if ch.isdigit()) != ''.join(ch for ch in settings.clinic_phone if ch.isdigit()): raise HTTPException(400,'pilot_destination_not_verified')
 result=call_request(CallRequest(name='Website caller',patient_contact=settings.clinic_phone,preferred_window='To be arranged',topic='AI receptionist call',consent=True))
 if result.get('mode')=='demo': return {'status':'demo_queued','provider':'mock','to':settings.clinic_phone,'message':'Demo mode: no real call was placed.'}
 return {'status':result['status'],'provider':'twilio','call_sid':result.get('request_id','').removeprefix('CALL-'),'to':settings.clinic_phone,'from':settings.twilio_phone_number}
@app.get('/api/calls/{request_id}')
def call_request_status(request_id:str):
 for item in repo.call_requests:
  if item['request_id']==request_id: return {k:item[k] for k in ('request_id','status','preferred_window','mode')}
 raise HTTPException(404,'call_request_not_found')
@app.post('/api/telephony/twilio/status-callback')
@app.post('/api/telephony/twilio/status')
async def twilio_status_callback(request:Request):
 params=await _twilio_params(request); _validate_twilio_request(request, params, request.headers.get('X-Twilio-Signature'))
 sid=params.get('CallSid',''); status=params.get('CallStatus','unknown')
 for item in repo.call_requests:
  if item.get('call_sid')==sid: item['status']=status
 repo.log('twilio_status',{'call_sid':sid,'status':status}); return {'received':True,'status':status}
@app.post('/api/admin/login')
def admin_login(r:AdminLoginRequest):
 email = settings.admin_initial_email or ('demo@example.test' if settings.mock_mode else '')
 password_ok = verify_password(r.password, _demo_admin_hash) if settings.mock_mode and not settings.admin_initial_password else (r.password == settings.admin_initial_password)
 if r.email != email or not password_ok: raise HTTPException(401,'invalid_credentials')
 repo.log('admin_login',{'email':r.email,'role':'admin'}); return {'access_token':_session_token(),'token_type':'bearer','role':'admin'}
@app.post('/api/telephony/twilio/webhook', response_class=HTMLResponse)
async def twilio_webhook(request: Request, x_twilio_signature: str|None=Header(default=None, alias='X-Twilio-Signature')):
 if settings.fish_speech_enabled:
  params = await _twilio_params(request)
  _validate_twilio_request(request, params, x_twilio_signature)
  return await _voice_response(request, settings.outbound_call_script)
 if settings.mock_mode:
  return HTMLResponse(TwilioVoiceGateway('', '', settings.twilio_phone_number).inbound_twiml(settings.outbound_call_script), media_type='application/xml')
 params = await _twilio_params(request)
 _validate_twilio_request(request, params, x_twilio_signature)
 return HTMLResponse(TwilioVoiceGateway(settings.twilio_account_sid, settings.twilio_auth_token, settings.twilio_phone_number).inbound_twiml(settings.outbound_call_script, settings.twilio_webhook_base_url), media_type='application/xml')
@app.post('/api/telephony/twilio/voice', response_class=HTMLResponse)
async def twilio_voice_followup(request: Request, x_twilio_signature: str|None=Header(default=None, alias='X-Twilio-Signature')):
    # Twilio posts the caller's recognized speech as SpeechResult.
    # CallSid is used as the conversation/session ID so every turn stays in context.
    params = await _twilio_params(request)
    _validate_twilio_request(request, params, x_twilio_signature)
    speech = (params.get('SpeechResult') or '').strip()
    call_sid = (params.get('CallSid') or 'twilio-demo-session').strip()

    if not speech:
        response_text = "I didn't quite catch that. Please tell me how I can help."
    else:
        try:
            result = agent.respond(speech, call_sid)
            if isinstance(result, dict):
                response_text = str(result.get('text') or result.get('response') or result.get('message') or result)
            else:
                response_text = str(getattr(result, 'text', None) or result)
        except Exception:
            response_text = "I'm sorry, I couldn't process that right now. Please try again or contact the clinic."

    return await _voice_response(request, response_text)
@app.post('/api/telephony/twilio/outbound', response_class=HTMLResponse)
async def twilio_outbound(request: Request):
    # Initial TwiML for an outbound call. The call is created by /api/calls/request.
    params = await _twilio_params(request)
    _validate_twilio_request(request, params, request.headers.get('X-Twilio-Signature'))
    return await _voice_response(request, settings.outbound_call_script)
@app.get('/api/usage')
def usage():
 pct=repo.usage['minutes']/3000*100; return {**repo.usage,'envelope_minutes':3000,'percent_used':round(pct,2),'threshold':'100%' if pct>=100 else '95%' if pct>=95 else '85%' if pct>=85 else '70%' if pct>=70 else 'below_70%'}
@app.get('/api/admin/config')
def get_config(authorization: str|None=Header(default=None)):
 if not _admin_allowed(authorization): raise HTTPException(403,'admin authorization required')
 return {'clinic':CLINIC,'services':SERVICES,'configuration_gaps':['live scheduling source','approved provider roster','pricing','consent wording','notification provider'],'roles':['receptionist','manager','admin','developer']}
@app.put('/api/admin/config')
def put_config(authorization: str|None=Header(default=None)):
 if not _admin_allowed(authorization): raise HTTPException(403,'admin authorization required')
 return get_config(authorization)
@app.get('/api/admin/activity')
def activity(authorization: str|None=Header(default=None)):
 if not _admin_allowed(authorization): raise HTTPException(403,'admin authorization required')
 return {'events':repo.events[-100:],'callbacks':repo.callbacks,'bookings':[{ 'reference':k,'status':v.status.value} for k,v in repo.bookings.items()]}
@app.get('/demo',response_class=HTMLResponse)
def demo():
 return HTMLResponse(DEMO_HTML)
DEMO_HTML="""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mouth Care Solutions</title><style>body{margin:0;background:#f5f8fb;color:#15324b;font:16px system-ui}header{background:#123d56;color:white;padding:28px 7%;display:flex;justify-content:space-between}main{max-width:1100px;margin:36px auto;padding:0 20px}.hero{background:#dff1ef;padding:38px;border-radius:22px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:22px;margin-top:22px}.card{background:white;padding:24px;border-radius:18px;box-shadow:0 8px 22px #123d5612}button{background:#e56b4b;color:white;border:0;border-radius:10px;padding:12px 18px;cursor:pointer;margin:5px}input{padding:12px;border:1px solid #ccd9df;border-radius:8px;width:90%}#log{min-height:140px;white-space:pre-wrap;background:#102f42;color:#dcf6f0;padding:16px;border-radius:10px}.slot{display:inline-block;border:1px solid #9cc8c1;padding:10px;border-radius:10px;margin:4px}</style></head><body><header><b>MOUTH CARE SOLUTIONS</b><span>AI Receptionist Demo</span></header><main><section class="hero"><h1>Calm, clear support for your next dental visit.</h1><p>Ask about the clinic, explore approved service categories, or try a demo appointment flow.</p><button onclick="ask('What are your clinic hours?')">Ask clinic hours</button><button onclick="ask('What dental services are available?')">View services</button><button onclick="ask('I need an appointment')">Request appointment</button></section><div class="grid"><section class="card"><h2>Receptionist chat</h2><input id="q" placeholder="Type a question…"><button onclick="ask(document.getElementById('q').value)">Send</button><div id="log">Ready. This is a mock/demo environment.</div></section><section class="card"><h2>Demo slots</h2><div id="slots">Loading…</div><h2>Human help</h2><input id="phone" placeholder="Phone number"><button onclick="callbackReq()">Request callback</button></section></div></main><script>const log=document.getElementById('log');window.addEventListener('unhandledrejection',()=>say('Something went wrong. Please try again or request a callback.'));function say(x){log.textContent=x+'\n\n'+log.textContent}async function ask(message){if(!message)return;const r=await fetch('/api/agent/session',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message})});const d=await r.json();say('You: '+message+'\nReceptionist: '+d.text);if(d.slots)render(d.slots)}async function load(){const r=await fetch('/api/slots');render((await r.json()).slots)}function render(slots){document.getElementById('slots').innerHTML=slots.map(s=>`<span class="slot">${new Date(s.starts_at).toLocaleString()}<br><button onclick="book('${s.id}')">Choose</button></span>`).join('')}async function book(id){const h=await fetch('/api/booking/hold',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({slot_id:id,session_id:'demo-browser',expiry_seconds:300})}).then(r=>r.json());const name=prompt('Your name (demo)');const phone=prompt('Your phone number (demo)');if(!name||!phone)return;const b=await fetch('/api/booking/confirm',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({hold_token:h.hold_token,patient_details:{name,phone},consent:true,idempotency_key:'browser-'+Date.now()})}).then(r=>r.json());say('Booking result: '+JSON.stringify(b));load()}async function callbackReq(){const phone=document.getElementById('phone').value;if(!phone)return say('Please enter a phone number.');const r=await fetch('/api/callback',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({patient_contact:phone,topic:'General assistance',preferred_window:'To be arranged'})});say('Callback request created: '+JSON.stringify(await r.json()))}load()</script></body></html>"""
