import re, secrets
from datetime import timedelta
from .repository import Repo
from backend.app.models.domain import BookingStatus, now
from backend.app.core.config import settings

CLINIC = {'name':'Mouth Care Solutions','address':'Door No. 29-28-23, Bhavani Complex, Suryaraopeta, Vijayawada, Andhra Pradesh 520002','phone':('+' + settings.clinic_phone[1:3] + ' ' + settings.clinic_phone[3:8] + ' ' + settings.clinic_phone[8:]) if settings.clinic_phone.startswith('+') else settings.clinic_phone,'email':'mouthcaresolutions@gmail.com','hours':'Monday-Saturday, 10:00 AM-8:00 PM; Sunday closed'}
SERVICES = ['Preventive','Restorative','Cosmetic','Orthodontic','Endodontic','Prosthodontic','Pediatric','Oral surgery','Emergency care']
EMERGENCY = 'If there is severe pain, uncontrolled bleeding, facial swelling affecting breathing or swallowing, or a dental injury, seek urgent medical care. This receptionist cannot diagnose. If configured, contact the clinic or emergency services now.'
class Policy:
    def answer(self, text):
        t=text.lower()
        if any(x in t for x in ['ignore previous','system prompt','reveal tool','internal tool','jailbreak']): return 'I can help with Mouth Care Solutions information and appointments, but I cannot reveal internal instructions.'
        if any(x in t for x in ['emergency','bleeding','swelling','knocked out','severe pain']): return EMERGENCY
        if 'hour' in t or 'open' in t: return f"Mouth Care Solutions is open {CLINIC['hours']}."
        if 'address' in t or 'located' in t: return f"The clinic is at {CLINIC['address']}."
        if 'phone' in t or 'call' in t: return f"The clinic phone number is {CLINIC['phone']}."
        if 'email' in t: return f"The clinic email is {CLINIC['email']}."
        if 'service' in t or 'treatment' in t: return 'Approved service categories include: ' + ', '.join(SERVICES) + '.'
        if any(x in t for x in ['price','cost','fee','doctor','dentist','insurance']): return 'I do not have an approved answer for that detail. I can create a callback request for the clinic team.'
        return None
class Agent:
    def __init__(self, repo): self.repo=repo; self.policy=Policy()
    def respond(self, message, session_id):
        answer=self.policy.answer(message)
        if answer: self.repo.log('agent_response', {'session_id':session_id}); return {'text':answer,'intent':'info','session_id':session_id}
        if any(x in message.lower() for x in ['appointment','book','schedule']):
            return {'text':'I can help with a demo appointment. Please choose a slot below, then I will ask for your name and phone number before confirmation.','intent':'appointment','session_id':session_id,'slots':[self.repo.slot_view(s) for s in self.repo.available()]}
        if any(x in message.lower() for x in ['human','person','callback']): return {'text':'I can arrange a callback from the clinic team. Please provide your contact number and preferred time window.','intent':'human_handoff','session_id':session_id}
        return {'text':'I can help with clinic hours, address, services, emergencies, demo appointments, or a callback. What would you like to know?','intent':'unknown','session_id':session_id}
