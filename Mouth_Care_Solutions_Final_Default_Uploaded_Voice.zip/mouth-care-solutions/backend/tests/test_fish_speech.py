import io
import math
import asyncio
import re
import wave

import pytest

from backend.app.adapters.fish_speech import AudioArtifact, FishSpeechAdapter, FishSpeechError
from backend.app.adapters.twilio import TwilioVoiceGateway
from fastapi.testclient import TestClient


def wav_bytes(sample_rate=16000, seconds=0.2):
    frames = int(sample_rate * seconds)
    samples = bytearray()
    for i in range(frames):
        value = int(8000 * math.sin(2 * math.pi * 440 * i / sample_rate))
        samples.extend(value.to_bytes(2, 'little', signed=True))
    output = io.BytesIO()
    with wave.open(output, 'wb') as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(bytes(samples))
    return output.getvalue()


class FakeResponse:
    content = wav_bytes()

    def raise_for_status(self):
        return None


class FakeClient:
    def __init__(self, *args, **kwargs):
        self.payload = None

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return False

    async def post(self, endpoint, json):
        self.payload = json
        return FakeResponse()


def test_fish_speech_generates_telephone_wav(monkeypatch):
    monkeypatch.setattr('backend.app.adapters.fish_speech.httpx.AsyncClient', FakeClient)
    adapter = FishSpeechAdapter('http://127.0.0.1:8080')
    artifact = asyncio.run(adapter.synthesize('Hello from the receptionist.'))
    assert artifact.source == 'fish-speech'
    assert artifact.sample_rate == 8000
    assert artifact.channels == 1
    assert artifact.duration_seconds > 0
    with wave.open(io.BytesIO(artifact.content), 'rb') as wav_file:
        assert wav_file.getframerate() == 8000
        assert wav_file.getnchannels() == 1
        assert wav_file.getsampwidth() == 2


def test_fish_speech_rejects_empty_text():
    adapter = FishSpeechAdapter('http://127.0.0.1:8080')
    with pytest.raises(ValueError, match='tts_text_required'):
        asyncio.run(adapter.synthesize('  '))


def test_fish_speech_payload_includes_reference_voice(tmp_path):
    reference = tmp_path / 'reference.wav'
    reference.write_bytes(b'reference-audio')
    adapter = FishSpeechAdapter(
        'http://127.0.0.1:8080',
        reference_audio=str(reference),
        reference_text='Reference speaker transcript.',
    )
    payload = adapter._payload('Hello from the receptionist.')
    assert payload['references'][0]['text'] == 'Reference speaker transcript.'
    assert payload['references'][0]['audio']


def test_missing_reference_voice_fails_cleanly():
    adapter = FishSpeechAdapter(
        'http://127.0.0.1:8080',
        reference_audio='/tmp/does-not-exist-mouth-care-reference.wav',
    )
    with pytest.raises(FishSpeechError, match='fish_speech_reference_unavailable'):
        asyncio.run(adapter.synthesize('Hello from the receptionist.'))


def test_fish_speech_twiml_uses_play_not_say():
    twiml = TwilioVoiceGateway('', '', '').audio_twiml(
        'https://example.test/api/telephony/audio/abc',
        'https://example.test',
    )
    assert '<Play>https://example.test/api/telephony/audio/abc</Play>' in twiml
    assert '<Say>' not in twiml
    assert '/api/telephony/twilio/voice' in twiml


def test_voice_route_integrates_fish_audio(monkeypatch):
    from backend.app import main

    async def fake_synthesize(text):
        return AudioArtifact('a' * 32, wav_bytes(8000), 'audio/wav', 8000, 1, 0.2, 0.01)

    monkeypatch.setattr(main.settings, 'fish_speech_enabled', True)
    monkeypatch.setattr(main.fish_speech, 'synthesize', fake_synthesize)
    response = TestClient(main.app).post(
        '/api/telephony/twilio/voice',
        data={'SpeechResult': 'What are your clinic hours?', 'CallSid': 'CA-test'},
    )
    assert response.status_code == 200
    assert '<Play>' in response.text
    assert '<Say>' not in response.text
    audio_id = re.search(r'/api/telephony/audio/([a-f0-9]+)', response.text).group(1)
    audio_response = TestClient(main.app).get(f'/api/telephony/audio/{audio_id}')
    assert audio_response.status_code == 200
    assert audio_response.headers['content-type'] == 'audio/wav'


def test_live_twilio_routes_require_signature(monkeypatch):
    from backend.app import main

    monkeypatch.setattr(main.settings, 'mock_mode', False)
    monkeypatch.setattr(main.settings, 'twilio_auth_token', 'test-token')
    monkeypatch.setattr(main.settings, 'twilio_webhook_base_url', 'https://voice.example.test')
    client = TestClient(main.app)
    for path in (
        '/api/telephony/twilio/webhook',
        '/api/telephony/twilio/voice',
        '/api/telephony/twilio/status',
        '/api/telephony/twilio/outbound',
    ):
        assert client.post(path, data={'CallSid': 'CA-test'}).status_code == 403


def test_ready_distinguishes_fish_configuration_and_reachability(monkeypatch):
    from backend.app import main

    monkeypatch.setattr(main.settings, 'mock_mode', True)
    monkeypatch.setattr(main.settings, 'fish_speech_enabled', False)
    demo = TestClient(main.app).get('/ready')
    assert demo.status_code == 200
    assert demo.json()['fish_speech'] == {'configured': False, 'reachable': False}

    monkeypatch.setattr(main.settings, 'mock_mode', False)
    monkeypatch.setattr(main.settings, 'fish_speech_enabled', True)
    monkeypatch.setattr(main.settings, 'fish_speech_base_url', 'http://fish-speech:8080')
    monkeypatch.setattr(type(main.settings), 'validate_live', lambda self: [])
    monkeypatch.setattr(main.httpx, 'get', lambda *args, **kwargs: (_ for _ in ()).throw(main.httpx.ConnectError('offline')))
    unavailable = TestClient(main.app).get('/ready')
    assert unavailable.status_code == 503
    assert unavailable.json()['detail']['fish_speech']['reachable'] is False
