# ElevenLabs setup

Set `MOCK_MODE=false`, `ELEVENLABS_API_KEY`, `ELEVENLABS_AGENT_ID`, and `ELEVENLABS_VOICE_ID` only after configuring an approved ElevenLabs agent and consent/recording wording. The provider seam covers session lifecycle, synthesis, audio send/receive, transcription, interruptions, timeouts, and usage accounting; the demo does not fake live audio. Validate the agent against the same policy and typed tools before exposing it to callers.
