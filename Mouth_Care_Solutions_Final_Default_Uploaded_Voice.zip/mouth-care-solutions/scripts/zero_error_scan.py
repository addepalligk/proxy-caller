#!/usr/bin/env python3
"""Static release gate; intentionally conservative and non-destructive."""
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
fail=[]
files=[p for p in root.rglob('*') if p.is_file() and '.venv' not in p.parts and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and 'dist' not in p.parts and p.name!='zero_error_scan.py']
text='\n'.join(p.read_text(errors='ignore') for p in files if p.suffix in {'.py','.md','.json','.yml','.yaml','.jsx','.js','.css','.sql','.example'} or p.name in {'.env.example','README.md'})
frontend_text='\n'.join(p.read_text(errors='ignore') for p in files if 'frontend' in p.parts)
for value,label in [('9866344866','retired clinic phone'),('98663 44866','retired formatted phone'),('demo-signature','legacy mock signature'),('http://localhost:8000','hard-coded frontend backend URL')]:
    if value in (frontend_text if label == 'hard-coded frontend backend URL' else text): fail.append(f'{label}: {value}')
required=['README.md','BUILD_REPORT.md','.env.example','Dockerfile','docker-compose.yml','migrations/001_initial.sql','backend/app/main.py','backend/app/adapters/llm.py','backend/app/adapters/twilio.py','frontend/package-lock.json','docs/code-audit.md']
for rel in required:
    if not (root/rel).exists(): fail.append(f'missing required file: {rel}')
for key in ['CLINIC_PHONE','TWILIO_PHONE_NUMBER','MOCK_MODE','LLM_API_KEY','ELEVENLABS_API_KEY','TWILIO_AUTH_TOKEN','DATABASE_URL']:
    if not re.search(r'^'+re.escape(key)+r'=', (root/'.env.example').read_text(), re.M): fail.append(f'missing env key: {key}')
source=(root/'backend/app/main.py').read_text()
for route in ['/api/agent/session','/api/knowledge/search','/api/slots','/api/booking/hold','/api/booking/confirm','/api/booking/reschedule','/api/booking/cancel','/api/callback','/api/telephony/twilio/webhook','/api/usage','/api/admin/config','/health','/ready']:
    if route not in source: fail.append(f'missing route reference: {route}')
if 'demo-admin-token' in text and 'mock_mode' not in source: fail.append('demo credential is not visibly isolated to mock mode')
# Detect obvious non-placeholder secret assignments, while allowing empty examples and documented demo values.
for p in files:
    s=p.read_text(errors='ignore')
    if p.name=='.env.example': continue
    if re.search(r'(sk-[A-Za-z0-9]{20,}|AC[a-f0-9]{30,}|AIza[A-Za-z0-9_-]{30,})',s): fail.append(f'secret-looking value: {p}')
if fail:
    print('ZERO_ERROR_SCAN_FAIL')
    print('\n'.join('- '+x for x in fail)); sys.exit(1)
print('ZERO_ERROR_SCAN_PASS')
print(f'scanned {len(files)} files; required references, configuration, stale-data, and secret checks passed')
