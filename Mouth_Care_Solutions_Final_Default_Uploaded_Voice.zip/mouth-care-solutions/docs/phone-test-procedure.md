# Live phone test procedure

1. Provision/configure the Twilio number and set credentials.
2. Configure ElevenLabs and PostgreSQL.
3. Start the backend behind HTTPS.
4. Verify `/health`, `/ready`, and the signed Twilio webhook externally.
5. Call `+91 96423 40630` only after it is actually provisioned/configured.
6. Ask about hours and approved services, request a demo/live appointment, explicitly confirm a slot, ask an unsupported price question, request a human, and hang up.
7. Verify PostgreSQL/admin records for call/session/correlation ID, tool events, outcome, audit events, and usage.

If credentials or provisioning are missing, report the exact blocker; do not claim the call works.
